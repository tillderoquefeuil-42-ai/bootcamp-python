import setuptools

setuptools.setup(
    name="ai42",
    version="1.0.0",
    author="tde-roqu",
    author_email="tde-roqu@student.42.fr",
    description="ai42 - bootcamp python - day02 - ex04",
    long_description="ai42 - bootcamp python - day02 - ex04",
    long_description_content_type="text/markdown",
    url="",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)