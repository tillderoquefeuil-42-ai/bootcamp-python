phrase = "The right format"

print('{:->42}'.format(phrase))

# > python kata03.py | cat -e 
# --------------------------The right format% 
# > python kata03.py | wc -c
#     42