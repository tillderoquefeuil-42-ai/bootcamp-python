t = (19,42,21)

print("The 3 numbers are: %d, %d, %d!" % t)

# > python kata00.py
# The 3 numbers are: 19, 42, 21!